﻿#include "LCD_Test.h"   //Examples

int main(void)
{
	Character_display();
    // Custom_char();
    // Direction_control();
    // Display_time();
    // Scroll_display();
    return 0;
}
